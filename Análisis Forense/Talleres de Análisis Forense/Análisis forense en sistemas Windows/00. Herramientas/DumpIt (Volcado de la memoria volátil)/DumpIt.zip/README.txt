- MoonSols Windows Memory "DumpIt" v1.3.2.20110401 -  

Copyright (C) 2010 - 2011, Matthieu Suiche <http://www.msuiche.net>
Copyright (C) 2010 - 2011, MoonSols <http://www.moonsols.com>

All executables and drivers are NOT redistributable, and licence applies only to one single
user. Reverse engineering is prohibited.

You are experiencing any problems contact us at : support@moonsols.com


This utility is used to generate a physical memory dump of Windows machines. It works with both x86 (32-bits) and x64 (64-bits) machines.
The raw memory dump is generated in the current directory, only a confirmation question is prompted before starting.
Perfect to deploy the executable on USB keys, for quick incident responses needs.